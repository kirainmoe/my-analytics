#define MYSQL_HOST "mysql"
#define MYSQL_USER "root"
#define MYSQL_PASS "root"
#define MYSQL_PORT 3306
